<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Tioanime</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php require_once "view/scripts.php"; ?>

</head>

<body class="dark">
	<div id="tioanime">
		<div class="row">
			<div class="col-md-12">
				<div align="center">								
					<form class="form-login" method="POST" action="<?php echo constant('URL'); ?>login/iniciarSesion" id="form-login" autocomplete="off">
						<div class="header">
							<p>Logueate</p>
						</div>
						<div class="form-group">
							<input type="text" name="correo" id="correo" class="form-control" placeholder="Correo electronico">
						</div>
						<div class="form-group">
							<input type="password" name="password" id="password" class="form-control" placeholder="password">
						</div>
						<div class="form-group">
							<button type="submit" id="login" class="btn btn-danger btn-block">Inciar sesion</button>
						</div>
						<hr>
						<div class="form-group">
							<a href="<?php echo constant('URL'); ?>registro" class="btn btn-info btn-block">Registrate</a>
						</div>
						<div id="errores">
						</div>
					</form>

				</div>
			</div>
		</div>
	</div>
	<?php require_once "view/script-body.php"; ?>
</body>

</html>