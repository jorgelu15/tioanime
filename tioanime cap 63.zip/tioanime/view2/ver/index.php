<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Directorio de Animes</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php require_once "view/scripts.php"; ?>
	
</head>
<body class="dark">
	<div id="tioanime">
		<?php require_once "view/navbar.php"; ?>
		<div class="container margin">
			
			<div class="row">
				<div class="col-md-8">
					<div class="header">
						<p>Nombre de Anime</p>
					</div>
					<br>
					<div class="list-option">
						<ul class="nav nav-pills nav-justified">
						  <li class="nav-item">
						    <a class="nav-link " href="#">Opcion 1</a>
						  </li>
						  <li class="nav-item">
						    <a class="nav-link" href="#">Opcion 2</a>
						  </li>
						  <li class="nav-item">
						    <a class="nav-link" href="#">Opcion 3</a>
						  </li>
						  <li class="nav-item">
						    <a class="nav-link" href="#">Opcion 4</a>
						  </li>
						  <li class="nav-item">
						    <a class="nav-link" href="#">Opcion 5</a>
						  </li>
						</ul>
					</div>
					<div class="canal">
						<iframe src="https://www.youtube.com/embed/qQfoFUgVV3I" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
				</div>
				<div class="col-md-4 ">
					<br><br><br>
					<?php require_once "view/comentario.php"; ?>
				</div>
			</div>
			
		</div>
		<?php require_once "view/footer.php"; ?>
	</div>
	<?php require_once "view/script-body.php"; ?>
</body>
</html>