<footer class=" footer">
			<div class="container">
				<img src="<?php echo constant('URL'); ?>public/img/logo-ft.png">
			</div>
		</footer>