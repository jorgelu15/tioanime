<?php
    class Capitulo {
        public $id;
        public $nombre;
        public $miniatura;
        public $url;
        public $anime;
        
    }