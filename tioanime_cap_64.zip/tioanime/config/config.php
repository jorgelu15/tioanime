<?php 

    define('URL', 'http://tioanime-testing.com/');
    define('HOST', 'localhost');
    define('DB', 'tioanime_db');
    define('USER', 'root');
    define('PASSWORD', '');
    define('CHARSET', 'utf8mb4');

?>