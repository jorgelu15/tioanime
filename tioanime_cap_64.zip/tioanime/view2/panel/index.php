<!DOCTYPE html>
<html lang="en">

<head>
	<title>Panel de Administracion</title>
	<?php require_once "view/scripts.php"; ?>
</head>

<body class="dark">
	<div id="fb-root"></div>
	<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v7.0"></script>
	<div id="tioanime">
		<header>
			<nav class="navbar navbar-expand-lg navbar-light bg-light">
				<a class="navbar-brand" href="#"><img src="../img/logo-dark.png"></a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav mr-auto">
						<li class="nav-item">
							<a class="nav-link" href="<?php echo constant('URL'); ?>main">INICIO<span class="sr-only">(current)</span></a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo constant('URL'); ?>directorio">DIRECTORIO</a>
						</li>
					</ul>
					<div>
						<form action="" method="post">
							<label>
								<input type="search" name="q" class="form-control col-12" placeholder="Buscar...">
							</label>
						</form>
					</div>
				</div>

			</nav>
		</header>

		<div class="container">
			<div class="row">
				<div class="col-md-8">

					<div class="panel-admin">
						<h1>Bienvenido <?php echo $this->usuario; ?></h1>
						<ul class="list-panel">
							<li class="list-panel-item">
								<div align="center">
									<a href="<?php echo constant('URL'); ?>agregarAnime"><i class="fas fa-pen-nib"></i></a>
									<p>Agregar Anime</p>
								</div>
							</li>
							<li class="list-panel-item">
								<div align="center">
									<a href="<?php echo constant('URL'); ?>agregarCapitulo"><i class="fas fa-upload"></i></a>
									<p>Subir Capitulo</p>
								</div>
							</li>
							<li class="list-panel-item">
								<div align="center">
									<a href="<?php echo constant('URL'); ?>lista"><i class="fas fa-clipboard-list"></i></a>
									<p>Lista de Animes</p>
								</div>
							</li>
							<li class="list-panel-item">
								<div align="center">
									<a href="<?php echo constant('URL'); ?>agregarCDC"><i class="fas fa-user-plus"></i></a>
									<p>Agregar un CDC</p>
								</div>
							</li>
							<li class="list-panel-item">
								<div align="center">
									<a href="<?php echo constant('URL'); ?>agregarCategorias"><i class="fas fa-user-plus"></i></a>
									<p>Agregar Categorias</p>
								</div>
							</li>
						</ul>
					</div>
				</div>
				<?php require "view/lista-panel.php"; ?>
			</div>
		</div>
		<footer class=" footer">
			<div class="container">
				<img src="../img/logo-ft.png">
			</div>
		</footer>
	</div>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>