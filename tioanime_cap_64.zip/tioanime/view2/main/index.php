<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Tioanime</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php require_once "view/scripts.php"; ?>
</head>
<body>
	<?php require_once "view/navbar.php"; ?>
	<div id="bg">
		<div class="container">
			<section class="banner">
				<section class="section-banner">
					<h1>Ultimas ovas</h1>
					<br>
					<article class="banner-box">
						<div class="thumb-banner">
							<img src="https://tioanime.com/uploads/portadas/3369.jpg" alt="">
						</div>
						<div class="txtBanner">
							Lorem ipsum dolor sit, amet consectetur adipisicing elit. Fuga, quo.
						</div>
					</article>
					<article class="banner-box">
						<div class="thumb-banner">
							<img src="https://tioanime.com/uploads/portadas/3369.jpg" alt="">
						</div>
						<div class="txtBanner">
							Lorem ipsum dolor sit, amet consectetur adipisicing elit. Fuga, quo.
						</div>
					</article>
					<div>
						<a href="" class="btn btn-primary">Ver Más...</a>
					</div>
				</section>
				<section class="section-banner">
					<h1>Ultimas ovas</h1>
					<br>
					<article class="banner-box">
						<div class="thumb-banner">
							<img src="https://tioanime.com/uploads/portadas/3369.jpg" alt="">
						</div>
						<div class="txtBanner">
							Lorem ipsum dolor sit, amet consectetur adipisicing elit. Fuga, quo.
						</div>
					</article>
					<article class="banner-box">
						<div class="thumb-banner">
							<img src="https://tioanime.com/uploads/portadas/3369.jpg" alt="">
						</div>
						<div class="txtBanner">
							Lorem ipsum dolor sit, amet consectetur adipisicing elit. Fuga, quo.
						</div>
					</article>
					<div>
						<a href="" class="btn btn-primary">Ver Más...</a>
					</div>
				</section>
				<section class="section-banner">
					<h1>Ultimas ovas</h1>
					<br>
					<article class="banner-box">
						<div class="thumb-banner">
							<img src="https://tioanime.com/uploads/portadas/3369.jpg" alt="">
						</div>
						<div class="txtBanner">
							Lorem ipsum dolor sit, amet consectetur adipisicing elit. Fuga, quo.
						</div>
					</article>
					<article class="banner-box">
						<div class="thumb-banner">
							<img src="https://tioanime.com/uploads/portadas/3369.jpg" alt="">
						</div>
						<div class="txtBanner">
							Lorem ipsum dolor sit, amet consectetur adipisicing elit. Fuga, quo.
						</div>
					</article>
					<div>
						<a href="" class="btn btn-primary">Ver Más...</a>
					</div>
				</section>
			</section>
			<br>
			<section class="wrapper">
				<h1>Ultimos Capitulos subidos</h1>
				<div class="articles">
					<?php
					foreach ($this->animes as $row) {
						$item = new Anime();
						$item = $row;
					?>
						<article class="card">
							<div class="thumb">
								<a href=""><img src="<?php echo $item->portada; ?>"></a>
							</div>
							<div class="txtTitle">
								<?php echo $item->titulo; ?>
							</div>
						</article>
					<?php } ?>
				</div>
				<h1>Ultimos Animes subidos</h1>
				<div class="articles">
					<?php
					foreach ($this->animes as $row) {
						$item = new Anime();
						$item = $row;
						
					?>							
						<article class="card">
							<div class="thumb">
								<a href=""><img src="<?php echo $item->portada; ?>"></a>
							</div>
							<div class="txtTitle">
								<?php echo $item->titulo; ?>
							</div>
							<?php
								if($item->tipo == 'SERIE') {	
									echo "<div>". $item->tipo."</div>";
								}else if($item->tipo == 'OVA'){
									echo "<div>". $item->tipo."</div>";
								}
							?>
						</article>
					<?php } ?>
				</div>
			</section>
		</div>
	</div>
	<?php require_once "view/footer.php"; ?>
	<?php require_once "view/script-body.php"; ?>
</body>

</html>