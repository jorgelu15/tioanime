<?php 
class Generos {
    public $id;
    public $genero;
}