<?php
interface IEstrategia {


    function filtrar($data, $page, $limit);


}