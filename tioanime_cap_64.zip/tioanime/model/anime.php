<?php

    class Anime {
        public $id;
        public $titulo;
        public $sinopsis;
        public $portada;
        public $miniatura;
        public $tipo;
        public $estado;
        public $anio;
    }