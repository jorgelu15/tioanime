<?php

    class Categorias {
        public $id;
        public $categoria;
    }