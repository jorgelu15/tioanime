<div class="col-md-4">
    <div class="panel-admin">
        <h1>Acciones</h1>
        <ul class="list-action-panel">
            <li class="list-action-panel-item">
                <a href="<?php echo constant('URL'); ?>panel">
                    Panel
                </a>
            </li>
            <li class="list-action-panel-item">
                <a href="<?php echo constant('URL'); ?>agregarCapitulo">
                    agregar Anime
                </a>
            </li>
            <li class="list-action-panel-item">
                <a href="<?php echo constant('URL'); ?>agregarCapitulo">
                    Agregar Capitulo
                </a>
            </li>
            <li class="list-action-panel-item">
                <a href="<?php echo constant('URL'); ?>lista">
                    Lista de Animes
                </a>
            </li>
            <li class="list-action-panel-item">
                <a href="a<?php echo constant('URL'); ?>agregarCDC">
                    agregar un CDC
                </a>
            </li>
            <li class="list-action-panel-item">
                <a href="<?php echo htmlentities(constant('URL') . 'panel/cerrarSession'); ?>">
                Cerrar Sesión
                </a>
            </li>
        </ul>
    </div>
</div>