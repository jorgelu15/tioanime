<li class="col-6 col-md-3 col-sm-4 col-xl-2">
							<article class="anime animes-directorio">
								<img src="<?php echo constant('URL'); ?>public/img/anime.jpg">
								<p>Nombre del anime</p>
							</article>
						</li>