<header>
	<div class="logo">
		<a href="<?php echo constant('URL'); ?>main">
			<img src="<?php echo constant('URL'); ?>public/img/logo-dark.png" />
		</a>
	</div>
	<nav class="main">
		<ul class="nav">
			<li class="nav-item"><i class="fas fa-mobile-alt"></i> <a href="https://play.google.com/store/apps/details?id=com.the_jakcal.dooplay.modagams&hl=es_419" target="_blank" class="app">Descargar App</a></li>
			<li class="nav-item"><a href="<?php echo constant('URL'); ?>main">INICIO</a></li>
			<li class="nav-item"><a href="<?php echo constant('URL'); ?>directorio">ANIMES</a></li>
			<li class="nav-item">
				<form>
					<input type="search" name="q" class="buscador" placeholder="Buscar..." autocomplete="off" />
				</form>
			</li>
		</ul>
	</nav>
	<div class="menu-toggle nav-toggle" id="btn-main">
		<i class="fas fa-bars"></i>
	</div>
</header>