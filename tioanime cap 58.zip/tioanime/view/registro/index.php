<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Tioanime</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<?php require_once "view/scripts.php"; ?>

</head>

<body class="dark">

	<div id="tioanime">
		<div class="row">
			<div class="col-md-12">
				<div align="center">

					<form class="form-login" method="POST" autocomplete="off" action="<?php echo  htmlentities(CONSTANT('URL') . 'registro/crear_usuario'); ?>" id="form">
						<div class="header">
							<p>Registrate</p>
						</div>
						<div class="form-group">
							<input type="text" name="username" id="username" class="form-control" placeholder="Nombre Usuario">
						</div>
						<div class="form-group">
							<input type="email" name="user" id="user" class="form-control" placeholder="Correo Electronico">
						</div>
						<div class="form-group">
							<input type="password" name="password" id="password" class="form-control" placeholder="password">
						</div>
						<div class="form-group">
							<input type="submit" id="registro" class="btn btn-info" value="Registrate">
						</div>
						<hr>
						<div class="form-group">
							<a href="<?php echo constant('URL'); ?>login" name="login" class="btn btn-danger btn-block" value="Iniciar Sesion">Iniciar Sesion</a>
						</div>
						<div id="errores">
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<?php require_once "view/script-body.php"; ?>
</body>

</html>