<?php 
    require "lib/database.php";
    require "lib/session.php";
    require "lib/model.php";
    require "lib/view.php";
    require "lib/controller.php";
    require "lib/app.php";

    require_once "config/config.php";

    

    $app = new App();
